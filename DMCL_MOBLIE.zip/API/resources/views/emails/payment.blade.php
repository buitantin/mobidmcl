<table>
	<tr>
		<td colspan='2'>
			<table>
				<tr>
					<td><span style='color: blue; font-size: 16px'>Thông
							tin trả góp sản phẩm</span></td>
				</tr>
				<tr>
					<td>
						<table border='1'>
							<tr>
								<th width='100px;'>Sản phẩm</th>
								<th width='80px;'>Hình ảnh</th>
								<th width='80px;'>Giá</th>
								<th>Loại hình trả góp</th>
								<th width='100px;'>Tỉ lệ trả trước</th>
								<th width='100px;'>Số tiền trả trước</th>
								<th width='90px;'>Số tháng góp</th>
								<th width='100px;'>Số tiền góp hàng tháng</th>
							</tr>
							<tr>
								<td>
				                <a target="_blank" href='http://dienmaycholon.vn/chi-tiet-san-pham/<?php echo $product['product']['myid']?>_may-giat-samsung-85-kg-ww85h5400ewsv_1_0' style='cursor:pointer;'><?php echo $product['product']['name']?></a>
				                </td>
				                <td>
				                <img src='http://static.dienmaycholon.vn/product/product<?php echo $product['product']['myid']?>/product_<?php echo $product['product']['myid']?>_1.png' style='width:60px; height:60px;' />
				                </td>
				                <td>
				            	   <?php echo $product['product']['discount']?>
				                </td>


								<td>TYPE</td>
								<td>PERCENT %</td>
								<td>SALE</td>
								<td>TIME</td>
								<td>PERMONTH</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<br /> <br />
		<br />
		</td>
	</tr>
	<tr>
		<td colspan='2'>
			<p>Hân hạnh được phục vụ quý khách, sau đây là một số thông tin
				về bán hàng trả góp của Siêu Thị Điện Máy - Nội Thất Chợ Lớn:</p> <a
			style='color: blue; text-decoration: underline; font-style: italic; font-weight: bold;'>Điều
				kiện tham gia: </a><br /> <span> Áp dụng cho tất cả khách hàng
				hộ khẩu tại Tp HCM và 64 tỉnh thành (xuất hóa đơn theo địa chỉ hộ
				khẩu) </span><br /> <a
			style='color: blue; text-decoration: underline; font-style: italic; font-weight: bold;'>Thông
				tin về trả góp:</a><br /> <span> Khoản trả trước: tối thiểu
				20%/giá trị sản phẩm hoặc 40%/giá trị sản phẩm (tùy thuộc vào chương
				trình trả góp) </span><br /> <span> Khoản tiền vay (bằng giá bán trừ
				khoản trả trước) thanh toán theo kỳ hạn : 6 – 9 – 12 tháng (tuỳ
				thuộc vào vào chương trình trả góp) </span><br /> <span> Thời gian
				xét duyệt: nhanh chóng (trễ nhất là 24 giờ) </span><br /> <a
			style='color: blue; text-decoration: underline; font-style: italic; font-weight: bold;'>Khi
				đến siêu thị đăng ký, quý khách vui lòng mang theo bản chính và bản
				photocopy (không cần sao y):</a><br /> <span> - CMND </span><br /> <span>
				- Hộ khẩu (photo nguyên cuốn) </span><br /> <span> - Một trong các
				hoá đơn điện hoặc nước hoặc điện thoại cố định, truyền hình cáp,
				internet (của 1 trong 3 tháng gần nhất), điện thoại di động trả sau
				của tháng gần..