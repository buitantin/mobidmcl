<?php namespace App;


class Slideshow extends Model {

	//
	protected  $table ='tm_slideshow';
	public $timestamps=false;

}
