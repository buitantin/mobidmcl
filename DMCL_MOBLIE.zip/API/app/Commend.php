<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Commend extends Model {
	protected	$table="question_content";
	public $timestamps =false;

	//

}
