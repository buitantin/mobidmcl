<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Orshipping extends Model {
	protected $table='or_shipping_address';
	public $timestamps =false;
	//

}
