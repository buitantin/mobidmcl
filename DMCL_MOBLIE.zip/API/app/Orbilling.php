<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Orbilling extends Model {

		protected $table='or_billing_address';
		public $timestamps =false;

}
