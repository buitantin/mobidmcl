<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use DB;
use Response;
class PageController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getListBranch($id)
	{
		$result=DB::table("tm_store")->whereRaw("status='1' AND is_area=$id")->get();
		return Response::json($result);
	}
	public function getDetailBranch($id){
		$result=DB::table("tm_store")->whereRaw("status='1' AND id=$id")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
		
	}
	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function getinstallment($id)
	{
		$result=DB::table("tm_installment")->whereRaw("id=$id")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}
	public function getmemberbenefits($id)
	{
		$result=DB::table("tm_memberbenefits")->whereRaw("id=$id")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function getpolicy()
	{
			$result=DB::table("art_pagecontent")->whereRaw("name LIKE 'Quy Định Giao Hàng'")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}
	public function getinfo()
	{
			$result=DB::table("art_pagecontent")->whereRaw("name LIKE 'Giới thiệu công ty'")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}
	public function getonline()
	{
			$result=DB::table("art_pagecontent")->whereRaw("name LIKE 'Hướng dẫn mua hàng online'")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}
	public function getmember()
	{
			$result=DB::table("art_pagecontent")->whereRaw("name LIKE 'Quyền Lợi Của Thành Viên'")->get();
		if(!empty($result[0])){
			return Response::json($result[0]);	
		}
		return '';
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

}
