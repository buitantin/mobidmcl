<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Orgift extends Model {
		protected $table='or_detail_gift';
	public $timestamps =false;
	//

}
