<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Ordetail extends Model {
		protected $table='or_detail';
	public $timestamps =false;
	//

}
