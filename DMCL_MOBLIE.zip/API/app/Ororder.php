<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Ororder extends Model {
		protected $table='or_order';
	public $timestamps =false;
	//

}
