// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic', 'starter.controllers','starter.services'])
.constant('ApiEndpoint', {
  url: '/affilliate/api',
  pageSize:5
})
// For the real endpoint, we'd use this
// .constant('ApiEndpoint', {
//  url: 'http://dienmaycholon.local/affilliate/api/login'
// })


.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard && window.cordova.plugins ) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
.config(function($stateProvider,$httpProvider, $urlRouterProvider) {
    $stateProvider
        .state('home', {
            url: '/home',
            abstract: true,
            templateUrl: 'templates/home.html',
             controller:"LoginCtrl"
          })

          .state('home.login', {
            url: '/login',
            views: {
              'home-login': {
                templateUrl: 'templates/home-login.html',
                controller:"LoginCtrl"
              }
            }
          })


//for login
    .state('tab', {
      url: '/tab',
      abstract: true,
      templateUrl: 'templates/tabs.html',
       controller:"DashCtr"
    })

    .state('tab.home', {
      url: '/home',
      views: {
        'tab-home': {
          templateUrl: 'templates/tab-home.html',
           controller:"DashCtr"
        }
      }
    })
    .state('tab.thunhap', {
      url: '/thunhap',
      views: {
        'tab-thunhap': {
          templateUrl: 'templates/tab-thunhap.html',
           controller:"DashCtr"
        }
      }
    })
    .state('tab.account', {
      url: '/account',
      views: {
        'tab-account': {
          templateUrl: 'templates/tab-account.html',
           controller:"DashCtr"
          //controller: 'AccountCtrl'
        }
      }
    })



    $urlRouterProvider.otherwise('/home/login');


})
