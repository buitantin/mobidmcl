angular.module('starter.controllers', [])
.controller("LoginCtrl",function($scope,LoginService){
	$scope.data={};

	$scope.login=function(){
           
		  LoginService.loginUser($scope.data.username, $scope.data.password).success(function(data) {
                         $state.go('tab.dash');
       			 }).error(function(data) {
                       
        });
	}
})
.controller("DashCtr",function($scope,$ionicSideMenuDelegate,ApiEndpoint,$http,$state,$ionicLoading,Session){
    if(isNaN(Session.data) && Object.keys(Session.data).length === 0){
       $state.go("home.login");
    }
        $scope.Session=Session;
        //For renue
        $scope.show_pagi=true;
        $scope.mystatus={
                        0 :"Đơn hàng vừa được tạo",
                        1 :" Đơn hàng đang xử lý",
                        4 :" Xử lý đơn hàng",
                        5 :" Đang xử lý",
                        6 : "Thu ngân ra phiếu",
                        7 : "Đang giao hàng",
                        2 : "Thành công",
                        3 : "Đơn hàng đã hủy"
                };
        $ionicLoading.show({
                content: '<i class="icon ion-loading-c"></i>',
                 animation: 'fade-in',
                template:"Đang tải dữ liệu..."
            });
        $http({
            method:"POST",
            url: ApiEndpoint.url+"/renue",
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
            data:{
                id: Session['data']['id']
            }

        })
        .success(function(data){
            $scope.list_income=data;
             var total_incom=Object.keys($scope.list_income).length;
             $scope.show_pagi= (total_incom > ApiEndpoint.pageSize ) ? true : false;
              $scope.pageS=total_incom;
             $ionicLoading.hide();
        })
        .error(function(stat){

            $ionicLoading.hide();
        });
          //Pagination

         $scope.currentPage=1;
         $scope.pageSize=$scope.currentPage* ApiEndpoint.pageSize;
         $scope.loadNextPage=function(){      
                            
                             $scope.currentPage++;
                             $scope.pageSize = $scope.currentPage * ApiEndpoint.pageSize
           }
        //For search
        $scope.search={};


        //Loading for form search
         $scope.show_search_form=false;
        $scope.loadDataSearch=function(){
            $scope.show_search_form=true;
             $scope.$broadcast('scroll.refreshComplete');
        }




        //left menu in header
        $scope.toggleLeft=function(){
            $ionicSideMenuDelegate.toggleLeft();
        }


        //For to price
        $scope.toPrice=function(price){
                if(!isNaN(price)){
                  return  number_format( price, 0, '.', ',' )+" Đ"; 
                }else{
                    return '0';
                }
        }

        //for current date
         var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; 

        var yyyy = today.getFullYear();
        if(dd<10){
            dd='0'+dd
        } 
        if(mm<10){
            mm='0'+mm
        } 
        $scope.datelc = dd+'/'+mm+'/'+yyyy;

        //For logout account
        $scope.logout=function(){
          /*  $http({
                method:"GET",
                url:ApiEndpoint.url+"/logout"

            }).success(function(data){
              
            })
*/
               $state.go("home.login");   
            
        }

        
        

})
.controller("renueCtrl",function($scope,$ionicSideMenuDelegate,ApiEndpoint,$http,$state,$ionicLoading,Session){
//for THuNhap
        $scope.product ={};

        $http({
            method:"POST",
            url: ApiEndpoint.url+"/thunhap",
             headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
            data:{
                id:  Session['data']['id']
            }

        })
        .success(function(data){
            $scope.product=data;
             for(var i=0;i<8;i++){
                if(isNaN($scope.product[i]))
                    $scope.product[i]=0;
            }
         
        })
        .error(function(){
        });


         $scope.product ={};

        $http({
            method:"POST",
            url: ApiEndpoint.url+"/tongthu",
             headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
            data:{
                id: Session['data']['id']
            }

        })
        .success(function(data){
            $scope.tongthu=data;
            
         
        })
        .error(function(){
        });
})


function number_format(number, decimals, decPoint, thousandsSep){
    decimals = decimals || 0;
    number = parseFloat(number);

    if(!decPoint || !thousandsSep){
        decPoint = '.';
        thousandsSep = ',';
    }

    var roundedNumber = Math.round( Math.abs( number ) * ('1e' + decimals) ) + '';
    var numbersString = decimals ? roundedNumber.slice(0, decimals * -1) : roundedNumber;
    var decimalsString = decimals ? roundedNumber.slice(decimals * -1) : '';
    var formattedNumber = "";

    while(numbersString.length > 3){
        formattedNumber += thousandsSep + numbersString.slice(-3)
        numbersString = numbersString.slice(0,-3);
    }

    return (number < 0 ? '-' : '') + numbersString + formattedNumber + (decimalsString ? (decPoint + decimalsString) : '');
}
