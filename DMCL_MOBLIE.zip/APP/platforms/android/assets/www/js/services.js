angular.module('starter.services', [])

.factory('LoginService', function($q,$state,$http,ApiEndpoint,$ionicPopup,$ionicLoading,Session) {
	return {
		loginUser: function(name,pw){
			var deferred = $q.defer();
			var promise = deferred.promise;
         $ionicLoading.show({
                template:"Đang đăng nhập..."
            });
        

        if( !name  || !pw ) {
                  $ionicLoading.hide();
                             $ionicPopup.alert({
                                      title: 'Vui lòng đăng nhập lại!',
                                     template: "Đăng nhập không thành công. Vui lòng nhập đầy đủ thông tin!"
                              }); 
         }else{
                            

            var request=$http({
                 method: "POST",
                  url:ApiEndpoint.url+"/login",
                 headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
                //contentType:"application/json; charset=utf-8",
               
                data:{
                    uname:name,
                    passwords:pw
                }
            });
            request.success(function(html){
              
                if(html.v=='1'){
                    Session.data= html.data;
                    $ionicLoading.hide();
                    $state.go("tab.home")
                }else{
                        $ionicLoading.hide();
                        if(html.v){
                              var alertPopup = $ionicPopup.alert({
                                title: 'Vui lòng đăng nhập lại!',
                                 template: html.v
                              });
                          }else{
                                 var alertPopup = $ionicPopup.alert({
                                      title: 'Vui lòng đăng nhập lại!',
                                     template: "Đăng nhập không thành công. Vui lòng kiểm tra lại thông tin!"
                              });
                          }
                      
                   // deferred.reject('Wrong credentials.');
                }
            })
            .error(function (data, status, headers, config) {

                      $ionicLoading.hide();
                      $ionicPopup.alert({
                        title:"Vui lòng đăng nhập Wifi.",
                        template:"Lỗi mạng"
                    });
            });
			
      
        }        
            
            promise.success = function(fn) {
                promise.then(fn);
                return promise;
            }
            promise.error = function(fn) {
                promise.then(null, fn);
                return promise;
            }
            return promise;
		}
	}
})
.factory("Session",function(){
    return {data:{}};
});

